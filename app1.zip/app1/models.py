from django.db import models

# Create your models here.

class Musician(models.Model):
    first_name = models.CharField(max_length=200)   #charfield String
    last_name = models.CharField(max_length=200)
    instrument = models.CharField(max_length=200)

class Album(models.Model):
    artist = models.ForeignKey(Musician, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    release_date = models.DateField()  #dateFiled for date
    num_stars = models.IntegerField()  #integer Fields

class Employee(models.Model):
    eid = models.IntegerField(max_length=10)
    empName = models.CharField(max_length=200)
    econtacts = models.CharField(max_length=15)
    class Meta:
        db_table="employee"