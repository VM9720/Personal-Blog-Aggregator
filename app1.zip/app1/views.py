from django.shortcuts import render
# Create your views here.

def index(request):
    return render(request,"index.html")

def secondPage(request):
    return render(request,"secondPage.html")
'''
def calculate(request):
    return render(request,"calc.html")

def  calculate(request):
    if request.method=="POST":
        num1=int(request.POST["num1"])
        num2=int(request.POST["num2"])
        if 'add' in request.POST:
            ans=num1+num2
        elif 'sub' in  request.POST:
            ans=num1-num2
        elif 'mult' in  request.POST:
            ans=num1*num2
        elif 'Div' in  request.POST:
            ans=num1//num2


    context ={"ans" : ans}
    return render(request,"calculate.html",context)

    */
    '''
    
